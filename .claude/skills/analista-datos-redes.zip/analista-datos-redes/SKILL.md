---
name: "analista-datos-redes"
description: "Usar cuando Carlos pida revisar cómo van su YouTube (DuplexDragon, @duplex_dragon) o su Instagram, qué contenido funciona, por qué bajaron las vistas, mejores horarios, o un reporte de rendimiento: mide con vidIQ, compara contra su propio promedio y entrega 3 decisiones concretas."
---

# Analista de datos (YouTube + Instagram)

Objetivo: que cada decisión de contenido salga de los números de Carlos, no de corazonadas. Siempre se termina con **3 decisiones accionables**, no con una tabla suelta.

## Cuentas

- YouTube: canal **DuplexDragon** `UCYlEih7xACf_uOIzXgE-ckg` (@duplex_dragon), conectado en vidIQ con cacarrillogomez2005@gmail.com.
- Instagram: verificar con `vidiq_instagram_connected_accounts`. Si sale vacío o `public_fallback`, mostrar `vidiq_connect_instagram_account` con `mode: "oauth"` (cuenta profesional/creador) y esperar. Sin owner insights solo hay datos públicos: decirlo así.

## Línea base medida (9 nov 2026)

- 545 suscriptores, 191 218 vistas, 34 videos. Casi todo es **Shorts de memes de Minecraft** en español (Colombia).
- Top: "MI AMIGO Y YO CUANDO VAMOS A MATAR AL WARDEN" (10 s, 33 K), "MINECRAFT COSAS QUE SUCEDEN EN MC" (29 s, 26 K, 30 comentarios), "POU: MENOS MAL QUE ESTABA TERMINANDO EL PUENTE" (21 s, 18 K).
- Patrón: **POV / "mi amigo vs yo" de 7-30 s** rinden 5-20× más que los de 1-3 min (adivina el patrón, impostor: 250-4 K).
- Último Short: 15 mar 2026. Ocho meses sin subir = el algoritmo dejó de empujar el canal; lo primero es volver a una frecuencia fija.
- Actualiza esta sección cuando cambien los números (fecha arriba).

## Flujo de análisis

1. **Datos** (en paralelo):
   - `vidiq_channel_analytics` / `vidiq_channel_performance_trends` (owner: retención, fuentes de tráfico, suscriptores ganados).
   - `vidiq_channel_videos` con `videoFormat: "short"` y `popular: true` y `false` (top vs recientes).
   - `vidiq_subscriber_insights` (cuándo está conectada la audiencia).
   - Instagram: `vidiq_instagram_owner_insights` (alcance, guardados, compartidos, watch time, skip rate) o `vidiq_ig_profile_reels` si solo hay públicos.
2. **Métricas que importan** (en este orden):
   - Shorts/Reels: % que ve vs desliza (skip rate), retención media, vistas en las primeras 48 h, compartidos y guardados por cada 1 000 vistas, suscriptores por video.
   - Engagement = (likes + comentarios×3 + compartidos×5 + guardados×5) / vistas. Comentarios y compartidos pesan más que likes.
   - `breakoutScore` de vidIQ: >100 = el video superó mucho al canal; estudiar su gancho.
3. **Comparar contra el propio canal**, no contra MrBeast: mediana de los últimos 10 videos. Un video es "ganador" si dobla la mediana.
4. **Encontrar el porqué**: agrupar por formato (POV, amigo vs yo, adivina, reacción), duración, tema (Warden, Nether, cuevas), hora y día. Ver qué tienen en común los 3 mejores: primer segundo, texto en pantalla, audio.
5. **Competencia y tendencias**: `vidiq_outliers` y `vidiq_instagram_tiktok_outlier_search` con "minecraft memes español" para ver qué formatos están explotando ahora; `vidiq_similar_channels` para referencias de tamaño parecido.
6. **Entregar**:
   - 3-5 líneas de diagnóstico.
   - Tabla pequeña: top 5 y peores 5 con la métrica clave.
   - **3 decisiones** ("haz más X", "deja Y", "prueba Z a las HH:MM") con la evidencia.
   - Si Carlos quiere verlo bonito: usa la skill `dataviz` y publica un artifact (dashboard).

## Reglas

- Nunca inventar números: si una herramienta no devuelve un dato, decir "no disponible".
- Mediana, no promedio (un viral distorsiona el promedio).
- Mínimo 5 videos para concluir algo de un formato; con menos es "señal", no regla.
- Revisión semanal (lunes) de los 7 días anteriores; revisión mensual con tendencias.
- Créditos vidIQ: revisa `vidiq_balance` antes de análisis grandes.
